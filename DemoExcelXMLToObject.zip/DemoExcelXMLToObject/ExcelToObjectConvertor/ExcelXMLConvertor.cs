﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Xml;
using Excel = Microsoft.Office.Interop.Excel;

namespace ExcelToObjectConvertor
{
    public static class ExcelXMLConvertor
    {
        private static List<WorkSheetInfo> workSheetsDTO;

        public static List<WorkSheetInfo> GetWortSheetsInfo(Stream inputStream, string fileName = @"")
        {
            try
            {
                if (!String.IsNullOrEmpty(fileName) && (Path.GetExtension(fileName) == @".xlsx"
                                                     || Path.GetExtension(fileName) == @".xls"))
                {
                    workSheetsDTO = GetWorkSheetInfoFromExcelFileStream(inputStream, fileName);
                }
                else
                {
                    if (inputStream != null && inputStream.CanRead)
                    {
                        workSheetsDTO = new List<WorkSheetInfo>();
                        XMLToObjectConvertor.ConfigureWorkSheet(inputStream);
                        if (XMLToObjectConvertor.WorkSheets != null && XMLToObjectConvertor.WorkSheets.Count() > 0)
                        {
                            foreach (WorkSheet workSheet in XMLToObjectConvertor.WorkSheets)
                            {
                                WorkSheetInfo workSheetDTO = ConvertWorkSheetToWorkSheetDTO(workSheet);
                                workSheetsDTO.Add(workSheetDTO);
                            }
                        }
                    }
                }
                inputStream.Close();
                return workSheetsDTO;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }
        public static List<WorkSheetInfo> GetWortSheetsInfo(XmlDocument xmlDocument)
        {
            try
            {
                if (xmlDocument != null)
                {
                    workSheetsDTO = new List<WorkSheetInfo>();
                    XMLToObjectConvertor.ConfigureWorkSheet(xmlDocument);
                    if (XMLToObjectConvertor.WorkSheets != null && XMLToObjectConvertor.WorkSheets.Count() > 0)
                    {
                        foreach (WorkSheet workSheet in XMLToObjectConvertor.WorkSheets)
                        {
                            WorkSheetInfo workSheetDTO = ConvertWorkSheetToWorkSheetDTO(workSheet);
                            workSheetsDTO.Add(workSheetDTO);
                        }
                    }
                }
                return workSheetsDTO;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }
        public static List<WorkSheetInfo> GetWortSheetsInfo(string fileFullPath)
        {
            try
            {
                if (File.Exists(fileFullPath))
                {
                    bool isConverted = false;
                    fileFullPath = ConvertToXMLFile(fileFullPath, ref isConverted);

                    if (Path.GetExtension(fileFullPath).ToLower() == ".xml")
                    {
                        XmlDocument xmlDocument = new XmlDocument();
                        xmlDocument.Load(fileFullPath);

                        workSheetsDTO = GetWortSheetsInfo(xmlDocument);
                    }

                    if (isConverted && File.Exists(fileFullPath))
                    {
                        File.Delete(fileFullPath);
                    }
                }
                return workSheetsDTO;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }
        public static List<WorkSheetInfo> GetWortSheetsInfo(FileInfo file)
        {
            try
            {
                if (File.Exists(file.FullName))
                {
                    bool isConverted = false;
                    string fileFullPath = ConvertToXMLFile(file.FullName, ref isConverted);

                    if (Path.GetExtension(fileFullPath).ToLower() == ".xml")
                    {
                        XmlDocument xmlDocument = new XmlDocument();
                        xmlDocument.Load(fileFullPath);

                        workSheetsDTO = GetWortSheetsInfo(xmlDocument);
                    }

                    if (isConverted && File.Exists(fileFullPath))
                    {
                        File.Delete(fileFullPath);
                    }
                }
                return workSheetsDTO;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }
        public static List<WorkSheetInfo> GetWortSheetsInfo(FileStream fileStream)
        {
            try
            {
                if (fileStream != null && fileStream.CanRead)
                {
                    string fileExtension = Path.GetExtension(fileStream.Name).ToLower();
                    if (fileExtension == @".xlsx" || fileExtension == @".xls")
                    {
                        workSheetsDTO = GetWorkSheetInfoFromExcelFileStream(fileStream, fileStream.Name);
                    }
                    else if (fileExtension == @".xml")
                    {
                        XmlDocument xmlDocument = new XmlDocument();
                        xmlDocument.Load(fileStream);
                        workSheetsDTO = GetWortSheetsInfo(xmlDocument);
                    }
                }
                fileStream.Close();
                return workSheetsDTO;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                fileStream.Close();
                return null;
            }
        }
        public static List<WorkSheetInfo> MapPropertyNameToHeaderName(string workSheetId, string propertyName, string headerName)
        {
            try
            {
                WorkSheetInfo workSheetInfo = workSheetsDTO.Where(w => w.WorkSheetId == workSheetId).FirstOrDefault();
                if (workSheetInfo != null)
                {
                    KeyValuePair<string, uint> headerNameInfo = workSheetInfo.First5RowsValueWithColumnNo
                                                                [int.Parse(workSheetInfo.HeaderRowIndex.ToString())]
                                                                .FirstOrDefault(hr => hr.Key.ToLower() == headerName.ToLower());
                    if (headerNameInfo.Key.ToLower() == headerName.ToLower())
                    {
                        uint columnNumber = headerNameInfo.Value;
                        MapPropertyNameToColumnNumber(workSheetId, propertyName, columnNumber);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return workSheetsDTO;
        }
        public static List<WorkSheetInfo> MapPropertyNameToColumnNumber(string workSheetId, string propertyName, uint columnNumber)
        {
            try
            {
                if (workSheetsDTO.Any(wh => wh.WorkSheetId == workSheetId
                    && !(wh.MappingPairs.Any(o => o.Key == propertyName || o.Value == columnNumber))))
                {
                    workSheetsDTO.Where(wh => wh.WorkSheetId == workSheetId
                    && !(wh.MappingPairs.Any(o => o.Key == propertyName || o.Value == columnNumber)))
                    .Select(wh =>
                    {
                        wh.MappingPairs
                        .Add(new KeyValuePair<string, uint>(propertyName, columnNumber));
                        return wh;
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return workSheetsDTO;
        }
        public static List<WorkSheetInfo> DeleteMappingPair(string workSheetId, string propertyName, uint columnNumber)
        {
            try
            {
                workSheetsDTO.Where(wh => wh.WorkSheetId == workSheetId &&
                wh.MappingPairs.Any(o => o.Key == propertyName || o.Value == columnNumber))
                .Select(wh =>
                {
                    wh.MappingPairs
                        .Remove(new KeyValuePair<string, uint>(propertyName, columnNumber));
                    return wh;
                }).ToList();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return workSheetsDTO;
        }
        public static List<WorkSheetInfo> DeleteAllMappingPair(string workSheetId)
        {
            try
            {
                workSheetsDTO.Where(wh => wh.WorkSheetId == workSheetId && wh.MappingPairs.Count > 0)
                .Select(wh =>
                {
                    wh.MappingPairs.Clear();
                    return wh;
                }).ToList();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return workSheetsDTO;
        }
        public static List<WorkSheetInfo> UpdateHasHeaderProperty(string workSheetId, bool hasHeader)
        {
            try
            {
                DeleteAllMappingPair(workSheetId);
                workSheetsDTO.Where(wh => wh.WorkSheetId == workSheetId)
                .Select(wh =>
                {
                    wh.HasHeader = hasHeader;
                    return wh;
                }).ToList();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return workSheetsDTO;
        }
        public static List<WorkSheetInfo> UpdateHeaderRowIndexProperty(string workSheetId, uint headerRowIndex)
        {
            try
            {
                if (headerRowIndex > 4)
                {
                    return workSheetsDTO;
                }
                DeleteAllMappingPair(workSheetId);
                workSheetsDTO.Where(wh => wh.WorkSheetId == workSheetId)
                .Select(wh =>
                {
                    wh.HeaderRowIndex = headerRowIndex;
                    return wh;
                }).ToList();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return workSheetsDTO;
        }
        public static List<WorkSheetInfo> UpdateObjectNameProperty(string workSheetId, string objectName)
        {
            try
            {
                DeleteAllMappingPair(workSheetId);
                workSheetsDTO.Where(wh => wh.WorkSheetId == workSheetId)
                .Select(wh =>
                {
                    wh.ObjectName = objectName;
                    return wh;
                }).ToList();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return workSheetsDTO;
        }
        public static List<T> GetObjectList<T>(string workSheetId) where T : new()
        {
            try
            {
                List<T> objectList = new List<T>();
                SetMappingPair<T>(workSheetId);
                WorkSheetInfo workSheetInfo = workSheetsDTO.Where(w => w.WorkSheetId == workSheetId).FirstOrDefault();
                if (workSheetInfo != null)
                {
                    XMLToObjectConvertor.UpdateMappingPair(workSheetInfo);
                    objectList = XMLToObjectConvertor.GetObjectList<T>(workSheetInfo.WorkSheetId);
                }
                return objectList;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        private static void SetMappingPair<T>(string workSheetId) where T : new()
        {
            try
            {
                WorkSheetInfo workSheetInfo = workSheetsDTO.Where(w => w.WorkSheetId == workSheetId).FirstOrDefault();
                if (workSheetInfo != null && workSheetInfo.HasHeader)
                {
                    int headerRowIndex = int.Parse(workSheetInfo.HeaderRowIndex.ToString());
                    List<KeyValuePair<string, uint>> headerRow = workSheetInfo.First5RowsValueWithColumnNo[headerRowIndex];
                    Type type = new T().GetType();

                    if (headerRow != null && headerRow.Count > 0)
                    {
                        foreach (KeyValuePair<string, uint> headerCell in headerRow)
                        {
                            try
                            {
                                if (!workSheetInfo.MappingPairs.Any(mpc => mpc.Value == headerCell.Value))
                                {
                                    string propertyName = Regex.Replace(headerCell.Key, @" |\s+", String.Empty);

                                    PropertyInfo propertyInfo = type.GetProperty(propertyName,
                                        BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.Instance);
                                    if (propertyInfo != null)
                                    {
                                        MapPropertyNameToColumnNumber(workSheetInfo.WorkSheetId, propertyInfo.Name,
                                                       headerCell.Value);
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.Message);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static WorkSheetInfo ConvertWorkSheetToWorkSheetDTO(WorkSheet worksheet)
        {
            try
            {
                WorkSheetInfo workSheetDTO = null;
                if (worksheet != null && !string.IsNullOrEmpty(worksheet.WorkSheetId))
                {
                    workSheetDTO = new WorkSheetInfo(worksheet.WorkSheetId, worksheet.WorkSheetName,
                                                    worksheet.First5Rows, worksheet.First5RowsValueWithColumnNo);
                    workSheetDTO.HasHeader = worksheet.HasHeader;
                    workSheetDTO.HeaderRowIndex = worksheet.HeaderRowIndex;
                    workSheetDTO.MappingPairs = worksheet.FinalMappingPair;
                }

                return workSheetDTO;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }

        }
        private static string ConvertToXMLFile(string fileFullPath, ref bool isConverted)
        {
            try
            {
                string fileExtension = Path.GetExtension(fileFullPath).ToLower();

                if (fileExtension == ".xlsx" || fileExtension == ".xls")
                {
                    string fileName = Path.GetFileNameWithoutExtension(fileFullPath);
                    string path = Path.GetDirectoryName(fileFullPath);
                    string xmlFileSavePath = String.Empty;

                    var excelApplication = new Excel.Application();
                    Excel.Workbook workBook = excelApplication.Workbooks.Add();

                    workBook = excelApplication.Workbooks.Open(fileFullPath);
                    xmlFileSavePath = Path.GetFullPath(AppDomain.CurrentDomain.BaseDirectory + @"\TemporaryFiles\");
                    if (!Directory.Exists(xmlFileSavePath))
                    {
                        Directory.CreateDirectory(xmlFileSavePath);
                    }
                    xmlFileSavePath = xmlFileSavePath + fileName + @".xml";
                    workBook.SaveAs(xmlFileSavePath, Excel.XlFileFormat.xlXMLSpreadsheet);

                    workBook.Close(fileFullPath);
                    excelApplication.Quit();
                    fileFullPath = xmlFileSavePath;
                    isConverted = true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return fileFullPath;
        }
        private static List<WorkSheetInfo> GetWorkSheetInfoFromExcelFileStream(Stream stream, string fileName)
        {
            try
            {
                string xlsfilePathWithName = AppDomain.CurrentDomain.BaseDirectory
                            + @"\TemporaryFiles\" + Path.GetFileNameWithoutExtension(fileName) + Path.GetExtension(fileName);
                if (!Directory.Exists(AppDomain.CurrentDomain.BaseDirectory + @"\TemporaryFiles\"))
                {
                    Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + @"\TemporaryFiles\");
                }
                FileStream tempxlsfileStream = File.Create(xlsfilePathWithName, int.Parse(stream.Length.ToString()));
                byte[] bytesInStream = new byte[int.Parse(stream.Length.ToString())];
                stream.Read(bytesInStream, 0, bytesInStream.Length);
                tempxlsfileStream.Write(bytesInStream, 0, bytesInStream.Length);
                tempxlsfileStream.Close();

                if (File.Exists(xlsfilePathWithName))
                {
                    var excelApplication = new Excel.Application();
                    Excel.Workbook workBook = excelApplication.Workbooks.Add();

                    workBook = excelApplication.Workbooks.Open(xlsfilePathWithName);

                    string xmlFileSavePath = Path.GetFullPath(AppDomain.CurrentDomain.BaseDirectory + @"\TemporaryFiles\");
                    if (!Directory.Exists(xmlFileSavePath))
                    {
                        Directory.CreateDirectory(xmlFileSavePath);
                    }
                    xmlFileSavePath = xmlFileSavePath + Path.GetFileNameWithoutExtension(fileName) + @".xml";

                    workBook.SaveAs(xmlFileSavePath, Excel.XlFileFormat.xlXMLSpreadsheet);

                    workBook.Close(xlsfilePathWithName);
                    excelApplication.Quit();
                    File.Delete(xlsfilePathWithName);

                    workSheetsDTO = GetWortSheetsInfo(xmlFileSavePath);
                    File.Delete(xmlFileSavePath);
                }
                return workSheetsDTO;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }
    }

    public class WorkSheetInfo
    {
        private readonly string workSheetId;
        private readonly string workSheetName;
        private readonly DataTable first5Rows;
        private readonly List<List<KeyValuePair<string, uint>>> first5RowsValueWithColumnNo;
        private List<KeyValuePair<string, uint>> mappingPair;

        public WorkSheetInfo(string workSheetId, string workSheetName, DataTable first5Rows,
                        List<List<KeyValuePair<string, uint>>> first5RowsValueWithColumnNo)
        {
            this.workSheetId = workSheetId;
            this.workSheetName = workSheetName;
            this.first5Rows = first5Rows;
            this.first5RowsValueWithColumnNo = first5RowsValueWithColumnNo;
            this.mappingPair = new List<KeyValuePair<string, uint>>();
        }

        public string WorkSheetId { get { return this.workSheetId; } }
        public string WorkSheetName { get { return this.workSheetName; } }
        public DataTable First5Rows { get { return this.first5Rows; } }
        public List<List<KeyValuePair<string, uint>>> First5RowsValueWithColumnNo { get { return this.first5RowsValueWithColumnNo; } }
        public uint HeaderRowIndex { get; set; }
        public uint RowStarterIndex { get { return HasHeader ? HeaderRowIndex + 1 : 0; } }
        public bool HasHeader { get; set; }
        public string ObjectName { get; set; }
        public List<KeyValuePair<string, uint>> MappingPairs
        {
            get { return this.mappingPair; }
            set { this.mappingPair = value; }
        }
    }
}
