﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Xml;

namespace ExcelToObjectConvertor
{
    internal static class XMLToObjectConvertor
    {
        #region PropertyAndArrtibute

        private static XmlNodeList workSheets;
        public static List<WorkSheet> WorkSheets { get; internal set; }
        #endregion

        internal static void ConfigureWorkSheet(Stream inputStream)
        {
            try
            {
                WorkSheets = new List<WorkSheet>();
                workSheets = null;
                GetWorkSheet(inputStream);
                InitializeWorkSheets();
            }
            catch (Exception ex)
            {

            }
        }
        internal static void ConfigureWorkSheet(XmlDocument xmlDocument)
        {
            try
            {
                WorkSheets = new List<WorkSheet>();
                workSheets = null;
                string query = @"//" + GetXPathCaseInsensitive("worksheet");
                workSheets = xmlDocument.SelectNodes(query);
                //workSheets = xmlDocument.SelectNodes(@"//*[local-name() = 'Worksheet']");
                InitializeWorkSheets();
            }
            catch (Exception ex)
            {

            }
        }
        internal static void UpdateMappingPair(WorkSheetInfo workSheetInfo)
        {
            try
            {
                WorkSheets.Where(wh => wh.WorkSheetId == workSheetInfo.WorkSheetId)
                    .Select(wh =>
                    {
                        wh.HasHeader = workSheetInfo.HasHeader;
                        wh.HeaderRowIndex = workSheetInfo.HeaderRowIndex;
                        wh.FinalMappingPair = workSheetInfo.MappingPairs;
                        return wh;
                    }).ToList();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        internal static List<T> GetObjectList<T>(string workSheetID) where T : new()
        {
            List<T> objList = new List<T>();
            WorkSheet workSheet = WorkSheets.Where(wh => wh.WorkSheetId == workSheetID).FirstOrDefault();
            if (workSheet != null && workSheet.rows != null
                && workSheet.FinalMappingPair != null && workSheet.FinalMappingPair.Count > 0)
            {
                XmlNodeList xmlrows = workSheet.rows;
                int rowStarterIndex = int.Parse(workSheet.RowStarterIndex.ToString());
                for (int rowIndex = rowStarterIndex; rowIndex < xmlrows.Count; rowIndex++)
                {
                    try
                    {
                        int numOfPropertyUpdate = 0;
                        T objctValue = GetSingleObject<T>(xmlrows[rowIndex], workSheet.FinalMappingPair, ref numOfPropertyUpdate);

                        if (objctValue != null && numOfPropertyUpdate > 0)
                        {
                            objList.Add(objctValue);
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
            }
            return objList;
        }

        #region PrivateMethogRegion

        private static T GetSingleObject<T>(XmlNode xmlNode, List<KeyValuePair<string, uint>> finalMappingPair, ref int noOfPropertyUpdate) where T : new()
        {
            T obj = new T();

            try
            {
                string queryCell = @"" + GetXPathCaseInsensitive("cell");
                XmlNodeList cells = xmlNode.SelectNodes(queryCell);
                //XmlNodeList cells = xmlNode.SelectNodes(@"*[local-name() = 'Cell']");
                if (cells != null && cells.Count > 0)
                {
                    uint actualCellIndex = 0;

                    foreach (XmlNode cell in cells)
                    {
                        try
                        {
                            actualCellIndex = GetActualCellIndex(cell.Attributes, actualCellIndex);
                            string data = GetDataFromCell(cell);
                            KeyValuePair<string, uint> propertyCellNumPair = finalMappingPair.FirstOrDefault(mpc =>
                                                                    mpc.Value == actualCellIndex);
                            if (!string.IsNullOrEmpty(propertyCellNumPair.Key) && !string.IsNullOrEmpty(data))
                            {
                                try
                                {
                                    PropertyInfo property = obj.GetType().GetProperty(propertyCellNumPair.Key);
                                    if (property != null)
                                    {
                                        Type propertyType = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;

                                        if (propertyType.IsEnum)
                                        {
                                            object safeValue = Enum.Parse(propertyType, data, true);

                                            property.SetValue(obj, safeValue, null);
                                            noOfPropertyUpdate++;
                                        }
                                        else if (propertyType.Name == typeof(Boolean).Name)
                                        {
                                            object safeValue = (data == "1" || data.ToLower() == "true" || data.ToLower() == "y"
                                                               || data.ToLower() == "t" || data.ToLower() == "yes") ? true : false;

                                            property.SetValue(obj, safeValue, null);
                                            noOfPropertyUpdate++;
                                        }
                                        else
                                        {
                                            object safeValue = Convert.ChangeType(data, propertyType);

                                            property.SetValue(obj, safeValue, null);
                                            noOfPropertyUpdate++;
                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine(ex.Message);
                                }
                            }
                        }

                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }

                        finally
                        {
                            actualCellIndex++;

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return obj;
        }
        private static void GetWorkSheet(Stream inputStream)
        {
            try
            {
                XmlDocument xmlDocument = new XmlDocument();
                XmlTextReader xmlTextReader = new XmlTextReader(inputStream);
                xmlDocument.Load(xmlTextReader);

                string query = @"//" + GetXPathCaseInsensitive("worksheet");
                workSheets = xmlDocument.SelectNodes(query);
                //workSheets = xmlDocument.SelectNodes(@"//*[local-name() = 'Worksheet']");
                xmlTextReader.Close();
                inputStream.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void InitializeWorkSheets()
        {
            if (workSheets != null && workSheets.Count > 0)
            {
                for (int index = 0; index < workSheets.Count; index++)
                {
                    try
                    {
                        XmlNode worksheet = workSheets[index];
                        string query = @"" + GetXPathCaseInsensitive("table") + @"/" + GetXPathCaseInsensitive("row");
                        XmlNodeList rows = worksheet.SelectNodes(query);
                        //XmlNodeList rows = worksheet.SelectNodes(@"*[local-name() = 'Table']/*[local-name() = 'Row']");
                        string workSheetName = GetWorkSheetName(worksheet.Attributes, index);

                        if (rows != null && rows.Count > 0)
                        {
                            List<List<KeyValuePair<string, uint>>> first5RowsValueWithColumnNo = new List<List<KeyValuePair<string, uint>>>();
                            int NoOfRows = rows.Count > 5 ? 5 : rows.Count;
                            uint headerRowIndex = 0;
                            DataTable first5RowDataTable = GetFirst5Rows(rows.Cast<XmlNode>().Take(NoOfRows).ToList(),
                                                                            ref first5RowsValueWithColumnNo, ref headerRowIndex);
                            WorkSheet workSheetObj = new WorkSheet(index.ToString(), workSheetName,
                                                                    first5RowDataTable, first5RowsValueWithColumnNo);
                            workSheetObj.rows = rows;
                            workSheetObj.HasHeader = true;
                            workSheetObj.HeaderRowIndex = headerRowIndex;
                            WorkSheets.Add(workSheetObj);
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
            }
        }
        private static string GetWorkSheetName(XmlAttributeCollection attributes, int index)
        {
            string Name = String.Empty;
            XmlAttribute nameAttribute = (from arrt in attributes.Cast<XmlAttribute>()
                                          where arrt.Name.ToLower().Contains("name") || arrt.Name.ToLower().EndsWith(":name")
                                          select arrt).FirstOrDefault();

            Name = String.IsNullOrEmpty(nameAttribute.Value) ? "Sheet_" + index.ToString() : nameAttribute.Value;
            return Name;
        }
        private static DataTable GetFirst5Rows(List<XmlNode> rows,
            ref List<List<KeyValuePair<string, uint>>> first5RowsValueWithColumnNo, ref uint headerRowIndex)
        {
            DataTable first5RowDataTable = new DataTable();
            int index = 0;
            bool isheaderRowIndexUpdate = false;
            try
            {
                foreach (XmlNode xmlNode in rows)
                {
                    DataRow dataRow = first5RowDataTable.NewRow();
                    string query = @"" + GetXPathCaseInsensitive("cell");
                    XmlNodeList cells = xmlNode.SelectNodes(query);
                    //XmlNodeList cells = xmlNode.SelectNodes(@"*[local-name() = 'Cell']");
                    List<KeyValuePair<string, uint>> rowKeyValue = new List<KeyValuePair<string, uint>>();

                    if (cells != null && cells.Count > 0)
                    {
                        uint actualCellIndex = 0;

                        foreach (XmlNode cell in cells)
                        {
                            try
                            {
                                actualCellIndex = GetActualCellIndex(cell.Attributes, actualCellIndex);
                                string data = GetDataFromCell(cell);
                                if (!string.IsNullOrEmpty(data))
                                {
                                    rowKeyValue.Add(new KeyValuePair<string, uint>(data, actualCellIndex));
                                }

                                String columnName = "Column" + actualCellIndex.ToString();
                                if (first5RowDataTable.Columns == null ||
                                    !first5RowDataTable.Columns.Contains(columnName))
                                {
                                    first5RowDataTable.Columns.Add(columnName, typeof(string));
                                }
                                dataRow[columnName] = data;
                            }
                            catch (Exception ex)
                            {

                            }
                            finally
                            {
                                actualCellIndex++;
                            }
                        }
                        if (!isheaderRowIndexUpdate)
                        {
                            isheaderRowIndexUpdate = true;
                            headerRowIndex = uint.Parse(index.ToString());
                        }
                    }
                    index++;
                    first5RowsValueWithColumnNo.Add(rowKeyValue);
                    first5RowDataTable.Rows.Add(dataRow);
                }
            }
            catch (Exception ex)
            {

            }
            return first5RowDataTable;
        }
        private static DataTable GetDataTableOfFirst5Rows(List<XmlNode> rows)
        {
            DataTable first5RowDataTable = new DataTable();
            try
            {
                foreach (XmlNode xmlNode in rows)
                {
                    DataRow dataRow = first5RowDataTable.NewRow();
                    XmlNodeList cells = xmlNode.SelectNodes(@"*[local-name() = 'Cell']");

                    if (cells != null && cells.Count > 0)
                    {
                        uint actualCellIndex = 0;

                        foreach (XmlNode cell in cells)
                        {
                            try
                            {
                                actualCellIndex = GetActualCellIndex(cell.Attributes, actualCellIndex);
                                string data = GetDataFromCell(cell);

                                String columnName = "Column" + actualCellIndex.ToString();
                                if (first5RowDataTable.Columns == null ||
                                    !first5RowDataTable.Columns.Contains(columnName))
                                {
                                    first5RowDataTable.Columns.Add(columnName, typeof(string));
                                }
                                dataRow[columnName] = data;
                            }
                            catch (Exception ex)
                            {

                            }
                        }
                    }
                    first5RowDataTable.Rows.Add(dataRow);
                }
            }
            catch (Exception ex)
            {

            }
            return first5RowDataTable;
        }
        private static string GetDataFromCell(XmlNode cell)
        {
            string query = @"" + GetXPathCaseInsensitive("data");
            XmlNode dataNode = cell.SelectSingleNode(query);
            //XmlNode dataNode = cell.SelectSingleNode(@"*[local-name() = 'Data']");
            string data = dataNode != null ? dataNode.InnerText.Trim() : String.Empty;
            return data;
        }
        private static uint GetActualCellIndex(XmlAttributeCollection attributes, uint actualCellIndex)
        {
            try
            {
                uint unitForParse;
                XmlAttribute indexAttribute = (from arrt in attributes.Cast<XmlAttribute>()
                                               where arrt.Name.ToLower().Contains("index") || arrt.Name.ToLower().EndsWith(":index")
                                               select arrt).FirstOrDefault();

                if (indexAttribute != null
                && uint.TryParse((indexAttribute.Value), out unitForParse)
                && unitForParse > 0)
                {
                    actualCellIndex = unitForParse - 1;
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return actualCellIndex;
        }
        private static string GetXPathCaseInsensitive(string queryNode)
        {
            string queryResult = @"*[translate(local-name(),"
                        + "'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz') = '"
                        + queryNode + "']";
            return queryResult;
        }

        #endregion
    }

    internal class WorkSheet
    {
        private readonly string workSheetId;
        private readonly string workSheetName;
        private readonly DataTable first5Rows;
        private readonly List<List<KeyValuePair<string, uint>>> first5RowsValueWithColumnNo;
        private List<KeyValuePair<string, uint>> finalMappingPair;

        public WorkSheet(string workSheetId, string workSheetName, DataTable first5Rows,
                        List<List<KeyValuePair<string, uint>>> first5RowsValueWithColumnNo)
        {
            this.workSheetId = workSheetId;
            this.workSheetName = workSheetName;
            this.first5Rows = first5Rows;
            this.first5RowsValueWithColumnNo = first5RowsValueWithColumnNo;
            this.finalMappingPair = new List<KeyValuePair<string, uint>>();
        }

        public string WorkSheetId { get { return this.workSheetId; } }
        public string WorkSheetName { get { return this.workSheetName; } }
        public DataTable First5Rows { get { return this.first5Rows; } }
        public List<List<KeyValuePair<string, uint>>> First5RowsValueWithColumnNo { get { return this.first5RowsValueWithColumnNo; } }
        public XmlNodeList rows { get; set; }
        public uint HeaderRowIndex { get; set; }
        public uint CellStarterIndex { get; set; }
        public uint RowStarterIndex { get { return HasHeader ? HeaderRowIndex + 1 : 0; } }

        public bool HasHeader { get; set; }
        public List<KeyValuePair<string, uint>> FinalMappingPair
        {
            get { return this.finalMappingPair; }
            set { this.finalMappingPair = value; }
        }
    }
}
