﻿using System;
using ExcelToObjectConvertor;
using System.Collections.Generic;
using DemoXMLExcelConvertorConsole.Models;
using System.IO;


namespace DemoXMLExcelConvertorConsole
{
    class Program
    {
        static void Main(string[] args)

        {
            string filePath = Path.GetFullPath(@"../../../ExcelFiles/PersonExcelSheet.xml"); // set your Excel file path
            StreamReader xd = new StreamReader(filePath);
            GetPersonFromMultipleSheet(xd.BaseStream);
            
            filePath = Path.GetFullPath(@"../../../ExcelFiles/PersonExcelSheet.xlsx"); // set your Excel file path
             xd = new StreamReader(filePath);
            GetPersonFromMultipleSheet(xd.BaseStream, @"PersonExcelSheet.xlsx");

            filePath = Path.GetFullPath(@"../../../ExcelFiles/PersonAccountExcel.xml"); // set your Excel file path
             xd = new StreamReader(filePath);
            GetDifferentObjectFromMultipleSheet(xd.BaseStream);

            filePath = Path.GetFullPath(@"../../../ExcelFiles/PersonAccountExcel.xlsx"); // set your Excel file path
             xd = new StreamReader(filePath);
            GetDifferentObjectFromMultipleSheet(xd.BaseStream, @"PersonAccountExcel.xlsx");

            filePath = Path.GetFullPath(@"../../../ExcelFiles/PersonAccountExcelOld.xls"); // set your Excel file path
             xd = new StreamReader(filePath);
            GetDifferentObjectFromMultipleSheet(xd.BaseStream, @"PersonAccountExcelOld.xls");

            filePath = Path.GetFullPath(@"../../../ExcelFiles/PersonExcel.xml"); // set your Excel file path. All spreadSheet have Same data type.
             xd = new StreamReader(filePath);
            GetPersonFromMultipleSheet(xd.BaseStream);
            
            Console.ReadKey();
        }

        private static void GetPersonFromMultipleSheet(Stream filePath, string fileName = @"")
        {
            if (filePath != null)
            {
                List<WorkSheetInfo> workSheetsInfo = ExcelXMLConvertor.GetWortSheetsInfo(filePath, fileName);
                List<Person> personList = new List<Person>();
                foreach (WorkSheetInfo workSheet in workSheetsInfo)
                {
                    personList.AddRange(GetPersonListBySheetName(workSheet));
                }
                Console.WriteLine("Total person: {0}", personList.Count);
            }
        }

        private static void GetDifferentObjectFromMultipleSheet(Stream filePath, string fileName = @"")
        {
            if (filePath != null)
            {
                List<WorkSheetInfo> workSheetsInfo = ExcelXMLConvertor.GetWortSheetsInfo(filePath, fileName);

                WorkSheetInfo workSheet = workSheetsInfo.Find(wh => wh.WorkSheetName == @"SheetAccount");
                if (workSheet != null && workSheet.WorkSheetId != null)
                {
                    List<Account> accountList = GetAccounttListBySheetName(workSheet);
                    Console.WriteLine("Total account: {0}", accountList.Count);
                }

                workSheet = workSheetsInfo.Find(wh => wh.WorkSheetName == @"SheetPerson");
                if (workSheet != null && workSheet.WorkSheetId != null)
                {
                    List<Person> personList = GetPersonListBySheetName(workSheet);
                    Console.WriteLine("Total person: {0}", personList.Count);
                }
            }
        }

        private static List<Person> GetPersonListBySheetName(WorkSheetInfo workSheet)
        {
            Person person = new Person();
            ExcelXMLConvertor.MapPropertyNameToHeaderName(workSheet.WorkSheetId, nameof(person.DateOfBirth), @"BOD");
            ExcelXMLConvertor.MapPropertyNameToHeaderName(workSheet.WorkSheetId, nameof(person.SerialNumber), @"Serial No.");
            ExcelXMLConvertor.MapPropertyNameToColumnNumber(workSheet.WorkSheetId, nameof(person.ID), 8);
            List<Person> personList = ExcelXMLConvertor.GetObjectList<Person>(workSheet.WorkSheetId);

            return personList;
        }

        private static List<Account> GetAccounttListBySheetName(WorkSheetInfo workSheet) 
        {
            Account account = new Account();
            ExcelXMLConvertor.MapPropertyNameToHeaderName(workSheet.WorkSheetId, nameof(account.AcctType), @"AccountType");
            ExcelXMLConvertor.MapPropertyNameToHeaderName(workSheet.WorkSheetId, nameof(account.BalanceAmount), @"balance");
            List<Account> accountList = ExcelXMLConvertor.GetObjectList<Account>(workSheet.WorkSheetId);

            return accountList;
        }
    }
}
