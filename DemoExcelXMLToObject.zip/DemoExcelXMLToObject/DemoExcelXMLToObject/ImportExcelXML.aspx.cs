﻿using System;
using ExcelToObjectConvertor;
using System.Collections.Generic;
using DemoExcelXMLToObject.Models;
using System.Reflection;
using System.Collections;
using System.Linq;
using System.IO;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.Data;
using System.Xml;

namespace DemoExcelXMLToObject
{
    public partial class ImportExcelXML : System.Web.UI.Page
    {
        private static List<WorkSheetInfo> workSheetInfoList;
        private static WorkSheetInfo selectedWorkSheet;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                PopulateDropDownListObject();
            }
        }

        #region Private Method
        
        private void GetWorkSheetsInfo()
        {
            try
            {
                workSheetInfoList = ExcelXMLConvertor.GetWortSheetsInfo(this.FileUploader.PostedFile.InputStream);
            }
            catch (Exception ex)
            {

            }

        }

        private void RemoveMappingPairs()
        {
            try
            {
                string workSheetId = this.DropDownListWorkSheet.SelectedValue;
                if (workSheetInfoList.Any(wh => wh.WorkSheetId == workSheetId
                                         && wh.MappingPairs != null
                                         && wh.MappingPairs.Count > 0))
                {
                    selectedWorkSheet.MappingPairs =
                                    workSheetInfoList.Where(wh => wh.WorkSheetId == workSheetId)
                                        .FirstOrDefault().MappingPairs = ExcelXMLConvertor.DeleteAllMappingPair(workSheetId)
                                        .Where(wh => wh.WorkSheetId == workSheetId).FirstOrDefault().MappingPairs;
                }

            }
            catch (Exception ex)
            {

            }
        }

        private void RemoveWorkSheetInfoList()
        {
            try
            {
                UnloadWorkSheetsInfo();
                selectedWorkSheet = null;
                workSheetInfoList = null;
            }
            catch (Exception ex)
            {

            }
        }

        #endregion

        #region Click Event
        protected void ButtonAddMappingPair_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.DropDownListWorkSheet.SelectedItem != null
                    && DropDownListProperty.SelectedItem != null && selectedWorkSheet != null)
                {
                    string workSheetId = this.DropDownListWorkSheet.SelectedValue;
                    if (selectedWorkSheet.WorkSheetId == workSheetId)
                    {
                        uint colNum;
                        bool isValidColNum;
                        if (this.RadioButtonByColNum.Checked)
                        {
                            isValidColNum = uint.TryParse(this.TextBoxColumnNumber.Text, out colNum);
                        }
                        else
                        {
                            isValidColNum = uint.TryParse(this.DropDownListHeaderRow.SelectedValue, out colNum);
                        }
                        if (isValidColNum)
                        {
                            selectedWorkSheet = ExcelXMLConvertor.MapPropertyNameToColumnNumber
                                                             (workSheetId, this.DropDownListProperty.SelectedValue, colNum)
                                                             .Where(wh => wh.WorkSheetId == workSheetId).FirstOrDefault();
                            PopulateMappingPair();
                        }

                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        protected void ButtonGetObjectList_Click(object sender, EventArgs e)
        {
            try
            {
                if (selectedWorkSheet != null && this.DropDownListObject.SelectedItem != null)
                {
                    MethodInfo method = typeof(ExcelXMLConvertor).GetMethod("GetObjectList");
                    Type type = Type.GetType(this.DropDownListObject.SelectedItem.Value, false);
                    MethodInfo genericMethod = method.MakeGenericMethod(type);
                    object[] args = { selectedWorkSheet.WorkSheetId };
                    object convertedObjects = genericMethod.Invoke(null, args);
                    IList convertedObjectsList = (IList)convertedObjects;
                    IEnumerable<object> objectsEnumerableList = convertedObjectsList.Cast<object>();

                    this.GridViewResultObjList.DataSource = convertedObjects;
                    this.GridViewResultObjList.DataBind();
                    this.NumberOfConvertedObject.Text = @"Total Object converted:" + objectsEnumerableList.Count();
                }
            }
            catch (Exception ex)
            {

            }
        }

        protected void btnUploadFile_Click(object sender, EventArgs e)
        {
            try
            {
                RemoveWorkSheetInfoList();

                if (this.FileUploader.HasFile)
                {
                    string fileExtension = Path.GetExtension(FileUploader.FileName).ToLower();
                    string fileName = Path.GetFileNameWithoutExtension(FileUploader.FileName);

                    if (fileExtension == ".xlsx" || fileExtension == ".xls")
                    {
                        workSheetInfoList = ExcelXMLConvertor.GetWortSheetsInfo(this.FileUploader.PostedFile.InputStream, 
                                            this.FileUploader.FileName);
                        PopulateWorkSheetInfo();
                    }
                    else if (fileExtension == ".xml")
                    {
                        GetWorkSheetsInfo();
                        PopulateWorkSheetInfo();
                    }
                }
                else
                {
                   ClientMessageBox.Show(@"No file have been selected", this);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                this.FileUploader.FileContent.Dispose();
                this.FileUploader.Dispose();
            }
        }

        #endregion

        #region Selection Change And Deletion
        protected void DropDownListObject_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                PopulateDropDownListProperty();
                RemoveMappingPairs();
                PopulateMappingPair();
            }
            catch (Exception ex)
            {

            }

        }

        protected void DropDownListWorkSheet_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                UnloadResultObjectList();
                PopulateSelectedWorkSheetInfo();
            }
            catch (Exception ex)
            {

            }

        }

        protected void GridViewFirst5Row_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (selectedWorkSheet != null)
                {
                    string workSheetId = this.DropDownListWorkSheet.SelectedValue;
                    if (selectedWorkSheet.WorkSheetId == workSheetId)
                    {
                        uint headerRowIndex;
                        bool isValidHeaderRowIndex = uint.TryParse(this.GridViewFirst5Row.SelectedIndex.ToString(), out headerRowIndex);

                        if (isValidHeaderRowIndex)
                        {
                            selectedWorkSheet = ExcelXMLConvertor.UpdateHeaderRowIndexProperty(workSheetId, headerRowIndex)
                                                                 .Where(wh => wh.WorkSheetId == workSheetId).FirstOrDefault();
                            PopulateHeaderRow();
                            PopulateMappingPair();
                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        protected void CheckBoxHasHeader_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (selectedWorkSheet != null)
                {
                    string workSheetId = this.DropDownListWorkSheet.SelectedValue;
                    if (selectedWorkSheet.WorkSheetId == workSheetId)
                    {

                        selectedWorkSheet = ExcelXMLConvertor.UpdateHasHeaderProperty
                                                         (workSheetId, this.CheckBoxHasHeader.Checked)
                                                         .Where(wh => wh.WorkSheetId == workSheetId).FirstOrDefault();
                        PopulateMappingPair();
                    }
                }
                UpdateCheckBoxHasHeader();
            }
            catch (Exception ex)
            {

            }
        }

        protected void RadioButtonMappingBy_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if(!this.CheckBoxHasHeader.Checked)
                {
                    this.RadioButtonByHeaderName.Checked = false;
                    this.RadioButtonByColNum.Checked = true;
                }
                UpdateRadioButtonMappingBy();
            }
            catch (Exception ex)
            {

            }

        }

        protected void GridViewMappingPair_RowDeleting(object sender, System.Web.UI.WebControls.GridViewDeleteEventArgs e)
        {
            try
            {
                string propertyName = GridViewMappingPair.Rows[e.RowIndex].Cells[1].Text;
                uint colNum;
                uint.TryParse(GridViewMappingPair.Rows[e.RowIndex].Cells[3].Text, out colNum);

                if (workSheetInfoList != null && this.DropDownListWorkSheet.SelectedItem != null
                    && selectedWorkSheet != null)
                {
                    string workSheetId = this.DropDownListWorkSheet.SelectedValue;
                    selectedWorkSheet.MappingPairs =
                    workSheetInfoList.Where(wh => wh.WorkSheetId == workSheetId)
                        .FirstOrDefault().MappingPairs = ExcelXMLConvertor.DeleteMappingPair(workSheetId, propertyName, colNum)
                                                .Where(wh => wh.WorkSheetId == workSheetId).FirstOrDefault().MappingPairs;
                    PopulateMappingPair();
                }
            }
            catch (Exception ex)
            {

            }
        }

        #endregion

        #region Upload Control

        private void UpdateCheckBoxHasHeader()
        {
            try
            {
                if (!this.CheckBoxHasHeader.Checked)
                {
                    this.RadioButtonByColNum.Checked = true;
                    this.RadioButtonByHeaderName.Checked = false;
                }
                else
                {
                    this.RadioButtonByColNum.Checked = false;
                    this.RadioButtonByHeaderName.Checked = true;
                }
                UpdateRadioButtonMappingBy();
            }
            catch (Exception ex)
            {

            }
        }

        private void UpdateRadioButtonMappingBy()
        {
            try
            {
                if (this.RadioButtonByColNum.Checked)
                {
                    this.TextBoxColumnNumber.Enabled = true;
                    this.DropDownListHeaderRow.Enabled = false;
                }
                else if (this.RadioButtonByHeaderName.Checked)
                {
                    this.TextBoxColumnNumber.Enabled = false;
                    this.DropDownListHeaderRow.Enabled = true;
                }
            }
            catch(Exception ex)
            {

            }
        }

        private void PopulateDropDownListProperty()
        {
            try
            {
                PropertyInfo[] selectedPropertyList = Type.GetType(this.DropDownListObject.SelectedValue).GetProperties();
                this.DropDownListProperty.DataSource = selectedPropertyList;
                this.DropDownListProperty.DataTextField = "Name";
                this.DropDownListProperty.DataValueField = "Name";
                this.DropDownListProperty.DataBind();
            }
            catch (Exception ex)
            {

            }
        }

        private void PopulateDropDownListObject()
        {
            try
            {
                List<KeyValuePair<object, string>> models = new List<KeyValuePair<object, string>>();

                foreach (object model in ModelsManipulation.GetModels())
                {
                    models.Add(new KeyValuePair<object, string>(model, model.ToString().Split('.').Last()));
                }
                this.DropDownListObject.DataSource = models;// ModelsManipulation.GetModels();
                this.DropDownListObject.DataTextField = "Value";
                this.DropDownListObject.DataValueField = "Key";
                this.DropDownListObject.DataBind();

                PopulateDropDownListProperty();
            }
            catch (Exception ex)
            {

            }
        }

        private void PopulateWorkSheetInfo()
        {
            try
            {
                if (workSheetInfoList != null && workSheetInfoList.Count > 0)
                {
                    this.DropDownListWorkSheet.DataSource = workSheetInfoList;
                    this.DropDownListWorkSheet.DataTextField = "WorkSheetName";
                    this.DropDownListWorkSheet.DataValueField = "WorkSheetId";
                    this.DropDownListWorkSheet.DataBind();
                    PopulateSelectedWorkSheetInfo();
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void PopulateSelectedWorkSheetInfo()
        {
            try
            {
                selectedWorkSheet = workSheetInfoList[this.DropDownListWorkSheet.SelectedIndex];
                this.GridViewFirst5Row.DataSource = selectedWorkSheet.First5Rows;
                this.GridViewFirst5Row.DataBind();
                this.CheckBoxHasHeader.Checked = selectedWorkSheet.HasHeader;
                UpdateCheckBoxHasHeader();
                PopulateHeaderRow();
                PopulateMappingPair();
            }
            catch (Exception ex)
            {

            }
        }

        private void PopulateHeaderRow()
        {
            try
            {
                int headerRowIndex = int.Parse(selectedWorkSheet.HeaderRowIndex.ToString());
                this.GridViewFirst5Row.SelectedIndex = headerRowIndex;
                this.TextBoxHeaderRowNumber.Text = headerRowIndex.ToString();
                this.DropDownListHeaderRow.DataSource = selectedWorkSheet.First5RowsValueWithColumnNo[headerRowIndex];
                this.DropDownListHeaderRow.DataTextField = "Key";
                this.DropDownListHeaderRow.DataValueField = "Value";
                this.DropDownListHeaderRow.DataBind();
            }
            catch (Exception ex)
            {

            }
        }

        private void PopulateMappingPair()
        {
            try
            {
                System.Data.DataTable dataTableMappingPair = new System.Data.DataTable();
                dataTableMappingPair.Columns.Add("Property Type", typeof(string));
                dataTableMappingPair.Columns.Add("Header Name", typeof(string));
                dataTableMappingPair.Columns.Add("Column Number", typeof(uint));

                int headerRowIndex = int.Parse(selectedWorkSheet.HeaderRowIndex.ToString());
                DataRow dataRow;

                foreach (KeyValuePair<string, uint> pair in selectedWorkSheet.MappingPairs)
                {
                    dataRow = dataTableMappingPair.NewRow();
                    dataRow["Property Type"] = pair.Key;
                    dataRow["Header Name"] = !selectedWorkSheet.HasHeader ? "..." :
                        selectedWorkSheet.First5RowsValueWithColumnNo[headerRowIndex]
                        .FirstOrDefault(wh => wh.Value == pair.Value).Key;
                    dataRow["Column Number"] = pair.Value;
                    dataTableMappingPair.Rows.Add(dataRow);
                }

                this.GridViewMappingPair.DataSource = dataTableMappingPair;
                this.GridViewMappingPair.DataBind();
            }
            catch (Exception ex)
            {

            }
        }

        #endregion

        #region Unload Control

        private void UnloadWorkSheetsInfo()
        {
            try
            {
                UnloadHeaderRows();
                UnloadHasHeader();
                UnloadMappingPair();
                UnloadRadioButtonGroupMappingBy();
                UnloadResultObjectList();
                this.DropDownListWorkSheet.DataSource = null;
                this.DropDownListWorkSheet.DataBind();
                this.DropDownListWorkSheet.Items.Clear();
            }
            catch (Exception ex)
            {

            }

        }

        private void UnloadHeaderRows()
        {
            try
            {
                this.GridViewFirst5Row.DataSource = null;
                this.GridViewFirst5Row.DataBind();
                this.DropDownListHeaderRow.DataSource = null;
                this.DropDownListHeaderRow.DataBind();
                this.TextBoxHeaderRowNumber.Text = string.Empty;
            }
            catch (Exception ex)
            {

            }

        }

        private void UnloadMappingPair()
        {
            try
            {
                this.GridViewMappingPair.DataSource = null;
                this.GridViewMappingPair.DataBind();
            }
            catch (Exception ex)
            {

            }

        }

        private void UnloadObjectsAndProperties()
        {
            try
            {
                this.DropDownListObject.DataSource = null;
                this.DropDownListObject.DataBind();
                this.DropDownListProperty.DataSource = null;
                this.DropDownListProperty.DataBind();
            }
            catch (Exception ex)
            {

            }

        }

        private void UnloadHasHeader()
        {
            try
            {
                this.CheckBoxHasHeader.Checked = false;
            }
            catch (Exception ex)
            {

            }

        }

        private void UnloadResultObjectList()
        {
            try
            {
                this.GridViewResultObjList.DataSource = null;
                this.GridViewResultObjList.DataBind();
                this.NumberOfConvertedObject.Text = string.Empty;
            }
            catch (Exception ex)
            {

            }

        }

        private void UnloadTextBoxColumnNumber()
        {
            this.TextBoxColumnNumber.Text = string.Empty;
        }

        private void UnloadRadioButtonGroupMappingBy()
        {
            this.RadioButtonByColNum.Checked = false;
            this.RadioButtonByHeaderName.Checked = false;
            UnloadTextBoxColumnNumber();
            this.DropDownListHeaderRow.Items.Clear();
            this.DropDownListHeaderRow.Enabled = true;
            this.TextBoxColumnNumber.Enabled = true;
        }
        #endregion
        
        protected override void Render(HtmlTextWriter writer)
        {
            try
            {
                this.Page.ClientScript.RegisterForEventValidation(this.DropDownListProperty.UniqueID, "0");
                this.Page.ClientScript.RegisterForEventValidation(this.DropDownListHeaderRow.UniqueID, "0");
                this.Page.ClientScript.RegisterForEventValidation(this.DropDownListObject.UniqueID, "0");
                this.Page.ClientScript.RegisterForEventValidation(this.DropDownListWorkSheet.UniqueID, "0");
                foreach (GridViewRow row in this.GridViewFirst5Row.Rows)
                {
                    if (row.RowType == DataControlRowType.DataRow)
                    {
                        row.Attributes["onclick"] = this.Page.ClientScript.GetPostBackClientHyperlink
                            (this.GridViewFirst5Row, "Select$" + row.RowIndex, true);

                    }
                }
            }
            catch (Exception ex)
            {

            }
            base.Render(writer);
        }
    }

    public static class ClientMessageBox
    {
        public static void Show(string message, Control owner)
        {
            Page page = (owner as Page) ?? owner.Page;
            if (page == null) return;

            page.ClientScript.RegisterStartupScript(owner.GetType(),
                "ShowMessage", string.Format("<script type='text/javascript'>alert('{0}')</script>",
                message));
        }
    }
}