﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DemoExcelXMLToObject.Models
{
    public class ModelsManipulation
    {
        public static List<object> GetModels()
        {
            List<object> models = new List<object>();
            try
            {
                models = new List<object>
               {
                   new Person(),
                   new Account()
               };
            }
            catch(Exception ex)
            {

            }
            return models;
        }
    }
}