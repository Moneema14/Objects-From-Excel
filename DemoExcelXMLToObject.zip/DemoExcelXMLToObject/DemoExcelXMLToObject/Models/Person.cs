﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DemoExcelXMLToObject.Models
{
    public class Person
    {
        public int? ID { get; set; }
        public string Name { get; set; }
        public string DistName { get; set; }
        public Nullable<System.DateTime> DateOfBirth { get; set; }
        public string AccountName { get; set; }
        public Nullable<decimal> BalanceAmount { get; set; }
        public Nullable<System.DateTime> AccountStartDate { get; set; }
        public Nullable<long> SerialNumber { get; set; }
        public string AddedBy { get; set; }
        public System.DateTime AddedDate { get; set; }
        public string UpdateBy { get; set; }
        public Nullable<System.DateTime> UpdatedDate { get; set; }
    }
    
}